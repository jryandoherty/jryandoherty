=== Simple Code Highlighter ===
Contributors: kedinn
Donate link: http://www.comoprogramar.org
Tags: syntax,code,button,codigo,highlighter
Requires at least: 4.0
Tested up to: 4.4
Stable tag: 4.0
License: GPL2
License URI: http://www.gnu.org/licenses/

Simple Syntax Code Highlighter

== Description ==

Simple Code Highlighter

The Code Highlighter Plugin uses Google Code Prettify Script to highlight your code. You don't need programming skills to use'it. Simply press the button on editor toolbar and paste your code. The plugin does all the rest.

See more details and usages guide here http://www.comoprogramar.org


== Installation ==

How to install the plugin and get it working.


1. Plugins > Add New. Search for "Simple Code Highlighter" then Install Now from the list and Activate
2. Plugins > Add New > Upload. Choose File "Simple Code Highlighter.zip" then Install Now and Activate
3. If you have direct access to the installation path, copy the zip file and extract to Plugin folder (usually wp-content/plugins). Then goto Plugins and Activate the plugin.


== Frequently Asked Questions ==

= Why this plugin? =

I needed a simple copy/paste for the code, no shortcodes, no writing a lot, just copy/paste.


== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png
3. screenshot-3.png


== Changelog ==

= 1.0 =
* Initial release. Just a simple button on the text editor

